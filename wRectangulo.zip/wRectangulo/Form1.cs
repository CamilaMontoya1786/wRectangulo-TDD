﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wRectangulo
{

    
    public partial class frmDibujarRectangulo : Form
    {
     
        public frmDibujarRectangulo()
        {
            //Se inicializa el formulario

            InitializeComponent();
           
        }

        
        private void btnDibujarRectangulo_Click(object sender, EventArgs e)
        {
            //Se utiliza e try para atrapar errores

            try
            {
                double x = double.Parse(txtX.Text);
                double y = double.Parse(txtY.Text);

                if (x != y)
                {
                    //inicializamos el objeto de rectangulo con la clase 
                    
                    clsRectangulo rectangle = new clsRectangulo(x, y);

                    //Respuesta invocando el método
                    txtResultado.Text = Convert.ToString(clsRectangulo.obtenerArea(Convert.ToInt32(txtX.Text), Convert.ToInt32(txtY.Text)));
                }
                else
                {

                    MessageBox.Show("Recuerde que para ser un rectángulo las medidas deben ser diferentes. :D");
                }
               
               
                


            }
            catch (Exception)
            {
                //Responde a la excepción

                MessageBox.Show("Digite un valor tipo númerico");
            }
        }
    }
}
