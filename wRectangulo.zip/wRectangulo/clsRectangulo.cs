﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wRectangulo
{

    /// <summary>
    /// Fecha: 31/08//2023
    /// Autor: Maria Camila Montoya Zapata - Jaider Oquendo Zapata
    /// Descripción: Aplicación de cálcular área de un rectángulo, utilizando TDD
    /// </summary>
    public class clsRectangulo

        //Definición d evariables
    {
        public int x;
        public int y;


        public clsRectangulo()
        {
            x = 0;
            y = 0;
        }

        public clsRectangulo(int x, int y)
        {
            this.x = x;
            this.y = y;

        }

        public clsRectangulo(double x, double y)
        {
            this.x = (int)x;
            this.y = (int)y;
        } 


        public static int obtenerArea(int y, int x) 
        {
            
            int Area = x * y;
            return Area;
        }
    
          
        
    }

}
